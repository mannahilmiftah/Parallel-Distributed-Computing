#include <mpi.h>
#include <iostream>
#include <fstream>
#include <string.h>
#include <vector>
#include <sstream>
#include <map>
#include <algorithm>
#include <sys/time.h>
using namespace std;

int count_file_lines(char file_name[]);
void compute_local_start_end(char file_name[], int my_rank, int comm_sz, int *local_start, int *local_end);
void read_file(char file_name[], int local_start, int local_end, vector< vector<string> > &matrix, map<string,float> &dictionary);
void find_itemsets(vector<string> matrix, vector<string> candidates, map<string,float> &temp_dictionary, int k, int item_idx, string itemset, int current, vector<string> single_candidates, int my_rank);
void prune_itemsets_MPI(map<string,float> &temp_dictionary, vector<string> &candidates, float min_support, int my_rank, int comm_sz, vector<string> &single_candidates);
void broadcast_freq_itemsets(vector<string> &freq_itemsets, int my_rank);
void update_candidates(vector<string> &candidates, vector<string> freq_itemsets, vector<string> &single_candidates, int rank);

int main(int argc, char** argv){
    MPI_Init(NULL, NULL);
    int comm_sz;
    MPI_Comm_size(MPI_COMM_WORLD, &comm_sz);
    int my_rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
    char file_name[] = "project.csv";
    float min_support = 0.01;
    vector< vector<string> > matrix;
    map<string,float> dictionary;
    map<string,float> temp_dictionary;
    vector<string> candidates;
    vector<string> single_candidates;
    int tot_lines;
    int local_start = 0, local_end = 0;
    string item;
    struct timeval start, end;
    double elapsed;
    gettimeofday(&start, NULL);
    compute_local_start_end(file_name, my_rank, comm_sz, &local_start, &local_end);
    
    // read file into 2D vector matrix and insert 1-itemsets in dictionary as key with their frequency as value
    read_file(file_name, local_start, local_end, matrix, dictionary);
    tot_lines = count_file_lines(file_name);
	cout << "Number of Lines read by Process " << my_rank << ": " << tot_lines << endl;

    // divide frequency by number of rows to calculate support
    for (map<string, float>::iterator i = dictionary.begin(); i != dictionary.end(); ++i) {
        i->second = i->second/float(tot_lines);
    }

    // prune from dictionary 1-itemsets with support < min_support and insert items in candidates vector
    prune_itemsets_MPI(dictionary, candidates, min_support, my_rank, comm_sz, single_candidates);
	for(int i = 0; i < comm_sz; i++){
		if(my_rank == i){
			for(auto j: candidates){
				cout << "Process " << my_rank << " ---inserted item--- " << j << endl;
			}
		}
	}

    // insert in dictionary all k-itemset
    int n = 2; // starting from 2-itemset
    while(!candidates.empty()){
        temp_dictionary.clear();
        // read matrix and insert n-itemsets in temp_dictionary as key with their frequency as value
        for (int i = 0; i < matrix.size(); i++){
            find_itemsets(matrix[i], candidates, temp_dictionary, n, -1, "", 0, single_candidates, my_rank);
        }

        // divide frequency by number of rows to calculate support
        for (map<string, float>::iterator i = temp_dictionary.begin(); i != temp_dictionary.end(); ++i) {
            i->second = i->second/float(tot_lines);
        }

        // prune from temp_dictionary n-itemsets with support < min_support and insert items in candidates vector
        prune_itemsets_MPI(temp_dictionary, candidates, min_support, my_rank, comm_sz, single_candidates);
        for(auto i:candidates){
        	cout << "Process " << my_rank << " ---found frequent item --- " << i << endl;
		}

        // append new n-itemsets to main dictionary
        if(my_rank == 0){
            dictionary.insert(temp_dictionary.begin(), temp_dictionary.end());
            for(auto i:temp_dictionary){
            cout << "Process 0 inserted item " << i.first << " with count " << i.second << endl;
			}
        }
        n++;
    }
    if(my_rank == 0){
        gettimeofday(&end, NULL);
        elapsed = (end.tv_sec - start.tv_sec) + ((end.tv_usec - start.tv_usec)/1000000.0);
        cout<<"Time passed: "<<elapsed<<endl;
        
        //removing extra space at the beginning of the word
	    for ( auto it = dictionary.begin(); it != dictionary.end(); ) {
	    	//const_cast is used to change the constant value of any object
	        string& key = const_cast<string&>(it->first);
	        size_t pos = key.find_first_not_of(' ');
	        if (pos != string::npos) {
	            key = key.substr(pos);
	            it++;
	        } else {
	            it = dictionary.erase(it);
	        }
	    }
	    
	    // to sort the items on the basis of support value
	    multimap<float,string> sorted_map;
	    for (auto& it : dictionary){
	    	sorted_map.insert({it.second, it.first});
		}
		cout << endl << endl;
		cout << "FREQUENT ITEMS ARE\n";
		
		//printing the most frequent items
		for (const auto& entry : sorted_map) {
			    const float& value = entry.first;
			    const string& key = entry.second;
			
			    if (key.find(" ") != string::npos) {
			        cout << key << endl;
			    }
		}

    }
    MPI_Finalize();
    return 0;
}

int count_file_lines(char file_name[]){
    int tot_lines = 0;=
    string line;
    ifstream myfile (file_name);
    while(getline (myfile, line)){
        tot_lines++;
    }
    myfile.close();
    return tot_lines;
}

void compute_local_start_end(char file_name[], int my_rank, int comm_sz, int *local_start, int *local_end){
    int tot_lines;
    int lines_per_each;
    *local_start = 0;
    *local_end = 0;
    tot_lines = count_file_lines(file_name);
    lines_per_each = tot_lines/comm_sz;
    if(tot_lines%comm_sz != 0){
        int zp = comm_sz - (tot_lines % comm_sz);
        for(int i=0; i<my_rank; i++){
            if(i >= zp){
                *local_start += lines_per_each + 1;
            }
            else{
                *local_start += lines_per_each;
            }
        }
        if(my_rank >= zp){
            lines_per_each++;
        }
        *local_end = *local_start + lines_per_each;
    }
    else{
        *local_start = lines_per_each*my_rank;
        *local_end = *local_start + lines_per_each;
    }
}

void read_file(char file_name[], int local_start, int local_end, vector<vector<string>> &matrix, map<string,float> &dictionary){
    int line_index = 0;
    ifstream myfile (file_name);
    vector<string> row;
    string line;
    stringstream ss;
    string item;
    while(getline (myfile, line)){
        if(line_index >= local_start & line_index < local_end){
            ss << line;
            while(getline (ss, item, ',')) {
                item.erase(remove(item.begin(), item.end(), '\r'), item.end());
                row.push_back(item);
                // insert item into dictionary and increment its value
                dictionary[item]++;
            }
            sort(row.begin(), row.end());
            matrix.push_back(row);
            ss.clear();
            row.clear();
        }
        if(line_index >= local_end) break;
        line_index++;
    }
    myfile.close();
}

void find_itemsets(vector<string> matrix, vector<string> candidates, map<string,float> &temp_dictionary, int k, int item_idx, string itemset, int current, vector<string> single_candidates, int rank){
    if(current == k){
        itemset = itemset.erase(0,1); // remove first space
	cout << "Process " << rank << " ---got itemset--- " << itemset << endl;
        // if itemset is a candidate insert it into temp_dictionary to calculate support 
        if(find(candidates.begin(), candidates.end(), itemset) != candidates.end()){
            temp_dictionary[itemset]++;
            return;
        }
        // if itemset is not a candidate discard it
        else{
            return;
        }
    }
    string item;
    for (int j = ++item_idx; j < matrix.size(); j++){
        item = matrix[j];
        // if item does not compose one of the candidates, skip it
        if(!(find(single_candidates.begin(), single_candidates.end(), item) != single_candidates.end())){
            continue;
        }
	//cout << "Process " << rank << " ---found frequent item--- " << item << endl;
        find_itemsets(matrix, candidates, temp_dictionary, k, j, itemset + " " + item, current+1, single_candidates, rank);
    }
}

void prune_itemsets_MPI(map<string,float> &temp_dictionary, vector<string> &candidates, float min_support, int my_rank, int comm_sz, vector<string> &single_candidates){
    string itemsets;
    string item;
    int count;
    vector<float> supports;
    stringstream ss;
    vector<string> freq_itemsets;
    if(my_rank != 0){
        for (map<string, float>::iterator i = temp_dictionary.begin(); i != temp_dictionary.end(); ++i) {
            itemsets.append('|' + i->first);
            supports.push_back(i->second);
        }
        itemsets.erase(0,1); // remove first char
        MPI_Send(&itemsets[0], itemsets.length()+1, MPI_CHAR, 0, 0, MPI_COMM_WORLD);
        MPI_Send(&supports[0], supports.size(), MPI_FLOAT, 0, 0, MPI_COMM_WORLD);
    }
    else{
        for(int i=1; i<comm_sz; i++){
            MPI_Status status;
            MPI_Probe(i, 0, MPI_COMM_WORLD, &status);
            MPI_Get_count(&status, MPI_CHAR, &count);
            char buf[count];
            MPI_Recv(&buf, count, MPI_CHAR, i, 0, MPI_COMM_WORLD, &status);
            itemsets = buf;
            MPI_Probe(i, 0, MPI_COMM_WORLD, &status);
            MPI_Get_count(&status, MPI_FLOAT, &count);
            supports.resize(count);
            MPI_Recv(&supports[0], count, MPI_FLOAT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            ss << itemsets;
            count = 0;
            while(getline (ss, item, '|')) {
                temp_dictionary[item] += supports[count];
                count++;
            }
            supports.clear();
            itemsets.clear();
            ss.clear();
        }
        // prune itemsets to obtain just frequent ones
        for (map<string, float>::iterator it = temp_dictionary.begin(); it != temp_dictionary.end(); ){ // like a while
            if (it->second < min_support){
                temp_dictionary.erase(it++);
            }
            else{
                freq_itemsets.push_back(it->first);
                ++it;
            }
        }
    }
    broadcast_freq_itemsets(freq_itemsets, my_rank);
    candidates.clear(); // empty candidates to then update it
    single_candidates.clear();
    if(!freq_itemsets.empty()){
        update_candidates(candidates, freq_itemsets, single_candidates, my_rank);
    }
}

void broadcast_freq_itemsets(vector<string> &freq_itemsets, int my_rank){
    char* buf;
    string itemsets;
    string item;
    int count;
    stringstream ss;
    if(my_rank == 0){
        for(int i=0; i<freq_itemsets.size(); i++) {
            itemsets.append('|' + freq_itemsets[i]);
        }
        itemsets.erase(0,1); // remove first char
        count = itemsets.length()+1;
    }
    MPI_Bcast(&count, 1, MPI_INT, 0, MPI_COMM_WORLD);
    if(my_rank == 0){
        buf = (char*)malloc(sizeof(char)*count);
        strcpy(buf, itemsets.c_str());
    }
    else{
        buf = (char*)malloc(sizeof(char)*count);
    }
    MPI_Bcast(&buf[0], count, MPI_CHAR, 0, MPI_COMM_WORLD);
    if(my_rank != 0){
        itemsets = buf;
        ss << itemsets;
        while(getline (ss, item, '|')) {
            freq_itemsets.push_back(item);
        }
    }
}

void update_candidates(vector<string> &candidates, vector<string> freq_itemsets, vector<string> &single_candidates, int rank){
    string item;
    stringstream to_combine;
    vector<string> items;
    vector<string> elements;
    string combination;
    int common_items;
    for(int i = 0; i < freq_itemsets.size()-1; i++){
        for(int j = i+1; j < freq_itemsets.size(); j++){
            common_items = 0;
            items.clear();
            to_combine.clear();
            combination.clear();
            to_combine << freq_itemsets[i] + ',' + freq_itemsets[j];
            while(getline (to_combine, item, ',')) {
                if(!(find(items.begin(), items.end(), item) != items.end())){
                    items.push_back(item);
                    combination += " " + item;
                }
                else{
                    common_items++;
                }
            }
						cout << "Process " << rank << "---found combination--- " << combination << endl;
            // if the statement is true than we can add combination as candidate
            // else we created all correct combinations and we pass to the next itemset
            if(common_items == items.size()-2){
                combination.erase(0,1); // remove first space
                candidates.push_back(combination);
                // insert single items candidates
                for(int i=0; i<items.size(); i++) {
                    if(!(find(single_candidates.begin(), single_candidates.end(), items[i]) != single_candidates.end())){
                        single_candidates.push_back(items[i]);
                    }
                }
            }
            else{
				cout << "Process " << rank << "---found combination--- " << combination << endl;
                break;
            }
        }
    }
}