#include <omp.h>
#include <windows.h>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <map>
#include <algorithm>
#include <sys/time.h>
using namespace std;

void read_file(char file_name[], vector< vector<string> > &matrix, map<string,float> &dictionary);
void find_itemsets(vector<string> matrix, vector<string> candidates, map<string,float> &temp_dictionary, int k, int item_idx, string itemset, int current, vector<string> single_candidates);
void prune_itemsets(map<string,float> &temp_dictionary, vector<string> &candidates, float min_support, vector<string> &single_candidates);
void update_candidates(vector<string> &candidates, vector<string> freq_itemsets, vector<string> &single_candidates);

// ------------------------------------------------------------
// Main
// ------------------------------------------------------------

int main(){
	ofstream outfile;
    outfile.open("Results.txt");
    char* file_name = "project.csv";
    float min_support = .01;
    vector< vector<string> > matrix;
    map<string,float> dictionary;
    map<string,float> temp_dictionary;
    vector<string> candidates;
    vector<string> single_candidates;
    vector<vector<string>> gotWords;
    vector<string> transaction;
    vector<string> combination;
    int n_rows;
    string item;

    cout<<"Max threads: "<<omp_get_max_threads()<<endl;

    struct timeval start, end;
    double elapsed;

    gettimeofday(&start, NULL);

    // read file into 2D vector matrix and insert 1-itemsets in dictionary as key with their frequency as value
    read_file(file_name, matrix, dictionary);

    n_rows = matrix.size();
	vector<string> gotword;
    // divide frequency by number of rows to calculate support
    #pragma omp parallel for ordered
    for (int i=0; i<dictionary.size(); i++) {
        map<string, float>::iterator itr = dictionary.begin();
        advance(itr, i);
        itr->second = itr->second/float(n_rows);
        sleep(.1);
        #pragma omp critical
        {
        	cout << "Thread " << omp_get_thread_num() << " ---Got Word--- " << itr->first << endl;
        	outfile << "Thread " << omp_get_thread_num() << " ---Got Word--- " << itr->first << endl;
		}
    }
	outfile.close();
    // prune from dictionary 1-itemsets with support < min_support and insert items in candidates vector
    prune_itemsets(dictionary, candidates, min_support, single_candidates);

    // insert in dictionary all k-itemset
    int n = 2; // starting from 2-itemset
    while(!candidates.empty()){
    	
        temp_dictionary.clear();
        // read matrix and insert n-itemsets in temp_dictionary as key with their frequency as value
        #pragma omp parallel for
        for (int i = 0; i < matrix.size(); i++){
        	
    		
        	#pragma omp critical
			{
				ofstream outfile;
    			outfile.open("Results.txt", ios::app);
	        	cout << "Thread " << omp_get_thread_num() << " ---Finding Items Of Transaction--- ";
	        	outfile << "Thread " << omp_get_thread_num() << " ---Finding Items Of Transaction--- ";
	        	for(auto j:matrix[i]){
					if(j.empty())
						continue;
					else
	        			cout << j << "\t";
	        			outfile << j << "\t";
	        	}
	        	outfile << endl;
        		cout << endl;
        	}
        	
        	
            find_itemsets(matrix[i], candidates, temp_dictionary, n, -1, "", 0, single_candidates);
        }
        outfile.close();
        // divide frequency by number of rows to calculate support
        #pragma omp parallel for
        for (int i=0; i<temp_dictionary.size(); i++) {
            map<string, float>::iterator itr = temp_dictionary.begin();
            advance(itr, i);
            itr->second = itr->second/float(n_rows);
        }
        // prune from temp_dictionary n-itemsets with support < min_support and insert items in candidates vector
        prune_itemsets(temp_dictionary, candidates, min_support, single_candidates);
        // append new n-itemsets to main dictionary
        dictionary.insert(temp_dictionary.begin(), temp_dictionary.end());
        n++;
    }

    gettimeofday(&end, NULL);
    elapsed = (end.tv_sec - start.tv_sec) + 
              ((end.tv_usec - start.tv_usec)/1000000.0);
    cout<<"Time passed: "<<elapsed<<endl;

    //removing extra space at the beginning of the word
    for ( auto it = dictionary.begin(); it != dictionary.end(); ) {
    	
    	//const_cast is used to change the constant value of any object
        string& key = const_cast<string&>(it->first);
        size_t pos = key.find_first_not_of(' ');
        //npos indicates no match was found
        if (pos != string::npos) {
            key = key.substr(pos);
            it++;
        } else {
            it = dictionary.erase(it);
        }
    }
    
    // to sort the items on the basis of support value
    multimap<float,string> sorted_map;
    for (auto& it : dictionary){
    	sorted_map.insert({it.second, it.first});
	}
	
	cout << endl << endl;
	cout << "FREQUENT ITEMS ARE\n";
	
	//printing the most frequent items
	for (const auto& entry : sorted_map) {
		    const float& value = entry.first;
		    const string& key = entry.second;
		
		    if (key.find(" ") != string::npos) {
		        cout << key << "\t" << value << endl;
		    }
	}

    return 0;
}


void read_file(char file_name[], vector< vector<string> > &matrix, map<string,float> &dictionary){
    ifstream myfile (file_name);

    vector<string> row;    
    string line;
    stringstream ss;
    string item;

    while(getline (myfile, line)){
        ss << line;

        while(getline (ss, item, ',')) {
            item.erase(remove(item.begin(), item.end(), '\r'), item.end());
            row.push_back(item);
            // insert item into dictionary and increment its value
            dictionary[item]++;
        }

        sort(row.begin(), row.end());
        matrix.push_back(row);

        ss.clear();
        row.clear();
    }

    myfile.close();
}

//																											n		-1				""				0
void find_itemsets(vector<string> matrix, vector<string> candidates, map<string,float> &temp_dictionary, int k, int item_idx, string itemset, int current, vector<string> single_candidates){
    if(current == k){
        itemset = itemset.erase(0,1); // remove first space

        // if itemset is a candidate insert it into temp_dictionary to calculate support 
        if(find(candidates.begin(), candidates.end(), itemset) != candidates.end()){

            #pragma omp critical
            temp_dictionary[itemset]++;
            return;
        }
        // if itemset is not a candidate discard it
        else{
            return;
        }
    }
    
    string item;
    for (int j = ++item_idx; j < matrix.size(); j++){
        item = matrix[j];

        // if item does not compose one of the candidates, skip it
        if(!(find(single_candidates.begin(), single_candidates.end(), item) != single_candidates.end())){
            continue;
        }

        find_itemsets(matrix, candidates, temp_dictionary, k, j, itemset + " " + item, current+1, single_candidates);
    }
}

void prune_itemsets(map<string,float> &temp_dictionary, vector<string> &candidates, float min_support, vector<string> &single_candidates){
    vector<string> freq_itemsets;
    candidates.clear(); // empty candidates to then update it
    single_candidates.clear();

    for (map<string, float>::iterator it = temp_dictionary.begin(); it != temp_dictionary.end(); ){ // like a while
        if (it->second < min_support){
            temp_dictionary.erase(it++);
        }
        else{
            freq_itemsets.push_back(it->first);
            ++it;
        }
    }

    if(!freq_itemsets.empty()){
        update_candidates(candidates, freq_itemsets, single_candidates);
    }
}

void update_candidates(vector<string> &candidates, vector<string> freq_itemsets, vector<string> &single_candidates){
    string item;
    stringstream to_combine;
    vector<string> items;
    vector<string> elements;
    string combination;

    int common_items;

    #pragma omp parallel for private(item, to_combine, items, elements, combination, common_items)
    for(int i = 0; i < freq_itemsets.size()-1; i++){
        for(int j = i+1; j < freq_itemsets.size(); j++){
            common_items = 0;
            items.clear();
            to_combine.clear();
            combination.clear();

            to_combine << freq_itemsets[i] + ',' + freq_itemsets[j];
            while(getline (to_combine, item, ',')) {
                if(!(find(items.begin(), items.end(), item) != items.end())){
                    items.push_back(item);
                    combination += " " + item;
                }
                else{
                    common_items++;
                }
            }

            // if the statement is true than we can add combination as candidate
            // else we created all correct combinations and we pass to the next itemset
            
			if(common_items == items.size()-2){
				ofstream outfile;
    			outfile.open("Results.txt", ios::app);
                combination.erase(0,1); // remove first space

                #pragma omp critical
                {   
                	
                    candidates.push_back(combination);
                    cout << "Thread " << omp_get_thread_num() << " ---Made Combination--- " << combination << endl;
                    outfile << "Thread " << omp_get_thread_num() << " ---Made Combination--- " << combination << endl;

                    // insert single items candidates
                    for(int i=0; i<items.size(); i++) {
                        if(!(find(single_candidates.begin(), single_candidates.end(), items[i]) != single_candidates.end())){
                            single_candidates.push_back(items[i]);
                        }
                    }
                    
                }
                outfile.close();
            }
            
            else{
                break;
            }

        }
    }
}